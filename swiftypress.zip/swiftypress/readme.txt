=== SwiftyPress ===
Contributors: basememara
Tags: mobile, mobile app, native app, ios, ios app, iphone app, apple, apple watch, wordpress mobile, android, android app, mobile web
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 4.7
Tested up to: 4.7
Stable tag: 0.3

Mobile app framework for your WordPress blog.

== Description ==

Mobile app framework for your WordPress blog.

== Installation ==
1. Upload swiftypress to the /wp-content/plugins/ directory
2. Activate the plugin through the \'Plugins\' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision

= 0.2 =
- Minor fixes

= 0.1 =
- Updated to WordPress REST API